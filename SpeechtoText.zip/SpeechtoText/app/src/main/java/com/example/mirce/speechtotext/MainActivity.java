package com.example.mirce.speechtotext;

import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    TextView text;

    /*
    public interface DelayCallback{
        void afterDelay();
    }

    public static void delay(int secs, final DelayCallback delayCallback){
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                delayCallback.afterDelay();
            }
        }, secs * 1000); // afterDelay will be executed after (secs*1000) milliseconds.
    }
    */
    Thread t;
    boolean finish = false;
    int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //final Handler handler = new Handler();
        //DisplayMetrics displayMetrics = new DisplayMetrics();
        //getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        //int height = displayMetrics.heightPixels;
        //int width = displayMetrics.widthPixels;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = findViewById(R.id.Text);

        text.setMovementMethod(new ScrollingMovementMethod());

        //try {
            //final Scanner sc = new Scanner(new File(getAssets().open("CopyPasta.txt")));



            //Environment.

            t = new Thread() {
                @Override
                public void run() {
                    try {
                        while (!isInterrupted()) {
                            Thread.sleep(2000);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
/*
                                try {

                                    String line;

                                    while ((line = br.readLine()) != null) {
                                        text.append(line);
                                        text.append('\n');
                                    }
                                    br.close();
                                }
                                catch (IOException e) {
                                    //You'll need to add proper error handling here
                                }*/
                                        try {

                                            if(!finish) {
                                                text.setText(" ");
                                                String fStr = "CopyPasta" + i + ".txt";
                                                InputStream is = getAssets().open(fStr);
                                                //for (String s: getAssets().) {
                                                //  text.append(s);
                                                //if(s.equals("CopyPasta" + (i+1) + ".txt")){
                                                i++;
                                                //}
                                                // }

                                                BufferedReader br = new BufferedReader(new InputStreamReader(is));

                                                while (br.ready() && !finish) {
                                                    text.append(br.readLine());
                                                    //br.reset();
                                                }

                                                is.close();
                                            }
                                        } catch (IOException IOE) {}
                                }

                            });
                        }
                    } catch (InterruptedException e) {
                    }
                }
            };
            t.start();
       // }catch(FileNotFoundException FNFE) {}
       // catch(IOException IOE){}


        text.setOnLongClickListener(new View.OnLongClickListener() {
            Boolean bot = true;
            //int tap = 1;

            @Override
            public boolean onLongClick(View v) {
                if (bot) {
                    text.setGravity(Gravity.NO_GRAVITY);
                    //text.scrollTo(0,0);
                    bot = false;
                }
                else {
                    text.setGravity(Gravity.BOTTOM);
                    bot = true;
                }

                //t.interrupt();
                return true;

            }
        });

    }

    public void buttonPress1(View view) {
        finish = true;
    }

    public void buttonPress2(View view) {
        finish = false;
    }

    public void buttonPress3(View view) {

    }
}
